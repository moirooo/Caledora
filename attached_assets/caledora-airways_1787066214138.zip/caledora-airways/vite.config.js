import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    host: true, // écoute sur 0.0.0.0, nécessaire pour l'aperçu Replit
    port: 3000,
    strictPort: true,
    allowedHosts: true, // autorise le domaine proxy *.replit.dev
  },
  preview: {
    host: true,
    port: 3000,
    strictPort: true,
    allowedHosts: true,
  },
})
