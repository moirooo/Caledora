# Caledora Airways — site web

Site multi-pages pour **Caledora Airways**, compagnie aérienne nationale fictive de
la République de Caledora, avec un tunnel de réservation simulé (recherche de vols,
sélection de sièges, confirmation).

Stack : **React + Vite + React Router**, en JavaScript pur (pas de TypeScript),
CSS "vanilla" avec variables de design (pas de framework CSS).

## Importer dans Replit

**Option A — zip**
1. Sur Replit : *Create App* → *Import from a folder / Upload zip*.
2. Sélectionnez ce fichier `.zip` et laissez Replit détecter le projet Node.js.
3. Une fois importé, cliquez sur **Run**. Replit exécute `npm install` puis `npm run dev`
   (voir `.replit`). Le site s'ouvre dans l'onglet Webview.

**Option B — dépôt Git**
1. Poussez ce dossier sur un dépôt GitHub.
2. Sur Replit : *Create App* → *Import from GitHub*, collez l'URL du dépôt.
3. Cliquez sur **Run**.

Si le Webview reste blanc au premier lancement, relancez **Run** une fois — le temps
que `npm install` termine.

## Commandes utiles

```bash
npm install       # installe les dépendances
npm run dev        # serveur de développement (http://localhost:3000)
npm run build       # build de production dans /dist
npm run preview      # sert le build de production localement
npm run lint       # vérifie le code (oxlint)
```

## Structure du projet

```
src/
  components/     # Navbar, Footer, Logo, HorizonScene, RouteLine, StepTracker, BookingLayout...
  context/        # BookingContext — état du tunnel de réservation (React Context)
  data/           # contenu du site : destinations, flotte, cabines, Aurora, historique
                  # + générateurs de vols et de plans de sièges fictifs (déterministes)
  pages/          # Accueil, Destinations, Flotte, Cabines, Aurora, À propos, 404
  pages/booking/  # les 4 étapes du tunnel : Recherche, Résultats, Sièges, Confirmation
  styles/         # layout.css, components.css, pages.css
  index.css       # tokens de design (couleurs, typographie, utilitaires)
```

## Notes de conception

- **Identité visuelle** : bleu marine profond (`#17365D`), doré (`#C89B3C`), fond ivoire —
  reprise des couleurs officielles indiquées dans la fiche compagnie, avec une direction
  artistique institutionnelle inspirée d'Air France (structure sobre, grands aplats de
  couleur, typographie éditoriale).
- **Motif signature** : une ligne d'horizon dorée (rayon solaire de l'empennage du logo)
  qui réapparaît comme fil conducteur — dans le hero, comme ligne de route entre deux
  aéroports, et comme suivi d'étapes dans le tunnel de réservation.
- **Typographies** : Fraunces (titres), Public Sans (interface), IBM Plex Mono (codes
  aéroport, prix, numéros de vol, références de réservation) — chargées depuis Google
  Fonts dans `index.html`.
- **Réservation simulée** : aucun back-end ni paiement réel. Les vols et plans de sièges
  sont générés côté client à partir d'une graine (origine + destination + date), donc les
  résultats sont cohérents si vous relancez la même recherche.
- Contenu et chiffres (flotte, réseau, historique, gouvernance) condensés à partir des
  fiches fournies (`Caledora_Airways_Format_Appli.txt`, `pays.txt`).

## Pistes d'évolution

- Remplacer les visuels SVG génériques (carte réseau, illustrations flotte/cabines) par
  de vraies photos ou illustrations de l'univers Caledora.
- Ajouter une vraie carte interactive du réseau (ex. Leaflet, comme pour la ville de
  Caledora) sur la page Destinations.
- Brancher un vrai favicon/logo si une version finale du logo est produite.
