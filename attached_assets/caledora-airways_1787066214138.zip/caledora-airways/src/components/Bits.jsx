export function SectionHeading({ eyebrow, title, lede, align = 'left' }) {
  return (
    <div className={`section-heading section-heading--${align}`}>
      {eyebrow && <span className="eyebrow">{eyebrow}</span>}
      <h2>{title}</h2>
      {lede && <p className="lede">{lede}</p>}
    </div>
  )
}

export function PageHeader({ eyebrow, title, lede }) {
  return (
    <section className="section--navy" style={{ paddingTop: 160, paddingBottom: 72 }}>
      <div className="container">
        <span className="eyebrow" style={{ marginBottom: 20, display: 'inline-flex' }}>{eyebrow}</span>
        <h1 style={{ fontSize: 'clamp(34px, 4.4vw, 54px)', maxWidth: '18ch' }}>{title}</h1>
        {lede && <p className="lede" style={{ marginTop: 20 }}>{lede}</p>}
      </div>
    </section>
  )
}

export function StatGrid({ stats }) {
  return (
    <div className="stat-grid">
      {stats.map((s) => (
        <div className="stat" key={s.label}>
          <span className="stat__value">{s.value}</span>
          <span className="stat__label">{s.label}</span>
          {s.suffix && <span className="stat__suffix">{s.suffix}</span>}
        </div>
      ))}
    </div>
  )
}
