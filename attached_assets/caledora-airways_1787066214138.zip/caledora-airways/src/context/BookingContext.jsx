import { createContext, useContext, useMemo, useState } from 'react'

const BookingContext = createContext(null)

const emptySearch = {
  origin: null,
  destination: null,
  date: '',
  returnDate: '',
  tripType: 'aller-retour',
  passengers: 1,
  cabin: 'Economy',
}

export function BookingProvider({ children }) {
  const [search, setSearch] = useState(emptySearch)
  const [selectedFlight, setSelectedFlight] = useState(null)
  const [selectedReturnFlight, setSelectedReturnFlight] = useState(null)
  const [selectedSeats, setSelectedSeats] = useState({})
  const [passengerNames, setPassengerNames] = useState([])
  const [bookingReference, setBookingReference] = useState(null)

  const resetBooking = () => {
    setSelectedFlight(null)
    setSelectedReturnFlight(null)
    setSelectedSeats({})
    setPassengerNames([])
    setBookingReference(null)
  }

  const value = useMemo(
    () => ({
      search,
      setSearch,
      selectedFlight,
      setSelectedFlight,
      selectedReturnFlight,
      setSelectedReturnFlight,
      selectedSeats,
      setSelectedSeats,
      passengerNames,
      setPassengerNames,
      bookingReference,
      setBookingReference,
      resetBooking,
    }),
    [search, selectedFlight, selectedReturnFlight, selectedSeats, passengerNames, bookingReference]
  )

  return <BookingContext.Provider value={value}>{children}</BookingContext.Provider>
}

export function useBooking() {
  const ctx = useContext(BookingContext)
  if (!ctx) throw new Error('useBooking must be used within BookingProvider')
  return ctx
}
